package view;

public interface View {

}
